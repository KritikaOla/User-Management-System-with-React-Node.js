import React from "react";
import ReactDOM from "react-dom/client"; // Use 'client' here
import App from "./App";

const root = ReactDOM.createRoot(document.getElementById("root"));
root.render(<App />);
