import React, { useState, useEffect } from "react";
import UserList from "./UserList";
import UserForm from "./UserForm";

const App = () => {
  const [users, setUsers] = useState([]);

  useEffect(() => {
    fetch("http://localhost:5000/users")
      .then((response) => response.json())
      .then((data) => setUsers(data))
      .catch((error) => console.error("Error fetching users:", error));
  }, []);

  const handleUserAdded = (newUser) => {
    setUsers([...users, newUser]); // Update UI without refresh
  };

  return (
    <div>
      <h1>User Management System</h1>
      <UserForm onUserAdded={handleUserAdded} />
      <UserList users={users} />
    </div>
  );
};

export default App;
