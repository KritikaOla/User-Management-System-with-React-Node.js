
import React, { Component } from "react";

class UserList extends Component {
  render() {
    return (
      <div>
        <h2>User List</h2>
        <ul>
          {this.props.users
            .filter(user => user.firstName && user.lastName && user.email && user.age) // Only display valid users
            .map((user) => (
              <li key={user.id}>
                <strong>{user.firstName} {user.lastName}</strong> - {user.email} | {user.gender} | Age: {user.age}
              </li>
            ))}
        </ul>
      </div>
    );
  }
}

export default UserList;
