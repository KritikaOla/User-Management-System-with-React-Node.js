import React, { useState } from "react";

const UserForm = ({ onUserAdded }) => {
  const [formData, setFormData] = useState({
    firstName: "",
    lastName: "",
    email: "",
    gender: "male",
    age: "",
  });

  const handleChange = (e) => {
    setFormData({ ...formData, [e.target.name]: e.target.value });
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    if (!formData.firstName.trim() || !formData.lastName.trim() || !formData.email.trim() || !formData.age.trim()) {
      alert("All fields are required!");
      return;
    }

    const newUser = { id: Date.now(), ...formData };

    try {
      const response = await fetch("http://localhost:5000/users", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(newUser),
      });

      if (response.ok) {
        onUserAdded(newUser);
        setFormData({ firstName: "", lastName: "", email: "", gender: "male", age: "" });
      }
    } catch (error) {
      console.error("Error adding user:", error);
    }
  };

  return (
    <form onSubmit={handleSubmit} style={styles.formContainer}>
      <div style={styles.inputGroup}>
        <label>Enter First Name:</label>
        <input type="text" name="firstName" value={formData.firstName} onChange={handleChange} />
      </div>

      <div style={styles.inputGroup}>
        <label>Enter Last Name:</label>
        <input type="text" name="lastName" value={formData.lastName} onChange={handleChange} />
      </div>

      <div style={styles.inputGroup}>
        <label>Enter Email:</label>
        <input type="email" name="email" value={formData.email} onChange={handleChange} />
      </div>

      <div style={styles.inputGroup}>
        <label>Select Gender:</label>
        <select name="gender" value={formData.gender} onChange={handleChange}>
          <option value="male">Male</option>
          <option value="female">Female</option>
        </select>
      </div>

      <div style={styles.inputGroup}>
        <label>Enter Age:</label>
        <input type="number" name="age" value={formData.age} onChange={handleChange} />
      </div>

      <button type="submit" style={styles.button}>Add User</button>
    </form>
  );
};

// Styling
const styles = {
  formContainer: {
    maxWidth: "500px",
    margin: "0 auto",
    padding: "20px",
    border: "1px solid #ccc",
    borderRadius: "8px",
    backgroundColor: "#f9f9f9",
    boxShadow: "0 0 10px rgba(0, 0, 0, 0.1)",
  },
  inputGroup: {
    marginBottom: "15px",
    display: "flex",
    flexDirection: "column",
  },
  button: {
    padding: "10px",
    backgroundColor: "#007BFF",
    color: "white",
    border: "none",
    borderRadius: "5px",
    cursor: "pointer",
  },
};

export default UserForm;
