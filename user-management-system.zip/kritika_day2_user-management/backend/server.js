const express = require("express");
const cors = require("cors");

const app = express();
const PORT = 5000;

// Middleware
app.use(cors());
app.use(express.json());

// Sample user data
let users = [
  { id: 1, name: "Alice" },
  { id: 2, name: "Bob" },
  { id: 3, name: "Charlie" }
];

// API route to get users
app.get("/users", (req, res) => {
  res.json(users);
});

// Start server
app.listen(PORT, () => {
  console.log(`Server is running on http://localhost:${PORT}`);
});

app.post("/users", (req, res) => {
    const newUser = req.body;
    users.push(newUser);
    res.status(201).json(newUser);
  });
  
  app.post("/users", (req, res) => {
    const newUser = req.body;
    users.push(newUser);
    res.status(201).json(newUser);
  });
  